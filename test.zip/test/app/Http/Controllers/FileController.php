<?php

namespace App\Http\Controllers;

use App\Models\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;
use ZipArchive;
use Symfony\Component\HttpFoundation\StreamedResponse;

class FileController extends Controller
{
    public function upload(Request $request)
    {
        
        // $request->validate([
        //     'file' => 'required|file|mimes:txt|max:2048', // Max size in kilobytes
        // ]);

        $request->validate([
            'file' => 'required|file|mimetypes:text/plain,application/hl7-v2|max:2048',
        ]);
        // $originalName = $request->file('file')->getClientOriginalName();
        // $path = $request->file('file')->storeAs('files', $originalName);
        // $file = File::create([
        //     'filename' => $originalName,
        //     'path' => $path,
        // ]);


        // Get the original filename
        $originalName = $request->file('file')->getClientOriginalName();
        // Store the file in the 'files' directory with its original name
        $path = $request->file('file')->storeAs('files', $originalName);
        // Save file metadata in the database
        $file = File::create([
            'filename' => $originalName,
            'path' => $path,
        ]);

        
        return response()->json([
            'message' => 'File uploaded successfully',
            'file' => $file,
        ], 201);
    }

    // public function downloadAllFiles()
    // {
    //     $files = Storage::files('files'); // Get all files in the 'files' directory
    
    //     // Create a temporary zip file
    //     $zip = new ZipArchive;
    //     $zipFileName = storage_path('app/temp_files.zip');
        
    //     if ($zip->open($zipFileName, ZipArchive::CREATE) === TRUE) {
    //         // Add files to the zip
    //         foreach ($files as $file) {
    //             $zip->addFile(storage_path('app/' . $file), basename($file));
    //         }
    //         $zip->close();
    //     } else {
    //         return response()->json(['error' => 'Could not create zip file'], 500);
    //     }

    //     if (file_exists($zipFileName)) {
    //         return response()->download($zipFileName)->deleteFileAfterSend(true);
    //     } else {
    //         return response()->json(['error' => 'Zip file not found'], 500);
    //     }
    
    // }


    public function ListFiles() {
        $files = Storage::files('/public/files'); // Get all files in the 'files' directory
    
        $fileUrls = [];
        foreach ($files as $file) {
            $fileUrls[] = url(Storage::url($file)); // Ensure full URLs are returned
        }

        return response()->json($fileUrls);
    }

   
    public function deleteAllFiles()
    {
        // Retrieve all file records from the database
        $files = File::all();

        foreach ($files as $file) {
            // Delete the file from storage
            if (Storage::exists($file->path)) {
                Storage::delete($file->path);
            }

            // Optionally, delete the file record from the database
            $file->delete();
        }

        return response()->json([
            'message' => 'All files have been deleted successfully.',
        ], 200);
    }
}

